# NZASSA MOBILITY — interface V4
Interface Flutter de démonstration, direction artistique premium : noir profond, blanc cassé et champagne doré.
- Accueil avec aperçu cartographique stylisé d'Abidjan (illustration, pas de GPS)
- Saisie du départ et de la destination
- Actions visuelles : programmer et ajouter un arrêt
- Sélection voiture, moto et taxi collectif
- Bandeau sécurité et navigation inférieure

## Générer l'APK
Importer le contenu de l'archive à la racine du dépôt GitHub, ouvrir Actions, lancer « Build NZASSA MOBILITY APK », puis télécharger l'artefact si le workflow réussit.

## Limites
Cette version est une maquette d'interface. Le GPS réel, la programmation, les arrêts, les comptes, réservations, paiement, dispatch chauffeurs, sécurité opérationnelle et tarifs réels restent à développer. Les prix affichés sont indicatifs.
